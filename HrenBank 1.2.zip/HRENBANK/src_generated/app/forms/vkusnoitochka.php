<?php
namespace app\forms;

use std, gui, framework, app;
use action\Score;
use action\Element; 

class vkusnoitochka extends AbstractForm
{

    /**
     * @event label3.construct 
     */
    function doLabel3Construct(UXEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Element::setText($e->sender, \action\Score::get('score'));

        
    }

    /**
     * @event button3.action 
     */
    function doButton3Action(UXEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Element::appendValue($this->label3, \action\Score::get('score'));

        
    }

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {    
        $money = Score::get('score');
        if ($money < 155){
            UXDialog::showAndWait('У вас нету 155 рублей!');
        }
        else{
            Score::inc('score', -155);
            UXDialog::showAndWait('Вы успешно купили бургер "Гранд"');
        }
    }

    /**
     * @event buttonAlt.action 
     */
    function doButtonAltAction(UXEvent $e = null)
    {
        $money = Score::get('score');
        if ($money < 232){
            UXDialog::showAndWait('У вас нету 232 рублей!');
        }
        else{
            Score::inc('score', -232);
            UXDialog::showAndWait('Вы успешно купили бургер "Двойной гранд"');
        }
    }

    /**
     * @event button4.action 
     */
    function doButton4Action(UXEvent $e = null)
    {
        $money = Score::get('score');
        if ($money < 109){
            UXDialog::showAndWait('У вас нету 109 рубля!');
        }
        else{
            Score::inc('score', -109);
            UXDialog::showAndWait('Вы успешно купили Фанту!');
        }
    }

}
