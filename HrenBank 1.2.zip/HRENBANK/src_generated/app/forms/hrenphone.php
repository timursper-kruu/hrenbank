<?php
namespace app\forms;

use std, gui, framework, app;


class hrenphone extends AbstractForm
{

    /**
     * @event image.click 
     */
    function doImageClick(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		$this->loadForm('spotify');

        
    }

}
