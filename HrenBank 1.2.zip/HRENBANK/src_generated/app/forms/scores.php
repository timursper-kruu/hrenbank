<?php
namespace app\forms;

use std, gui, framework, app;
use action\Element; 


class scores extends AbstractForm
{

    /**
     * @event labelAlt.construct 
     */
    function doLabelAltConstruct(UXEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Element::setText($e->sender, \action\Score::get('score'));

        
    }

    /**
     * @event label4.construct 
     */
    function doLabel4Construct(UXEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Element::setText($e->sender, \action\Score::get('tsumbalance'));

        
    }

}
