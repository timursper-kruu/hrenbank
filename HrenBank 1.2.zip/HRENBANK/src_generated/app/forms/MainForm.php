<?php
namespace app\forms;

use std, gui, framework, app;
use action\Element; 


class MainForm extends AbstractForm
{

    $money = 0;

    /**
     * @event moneybalance.construct 
     */
    function doMoneybalanceConstruct(UXEvent $e = null)
    {    
        
    }



    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		$this->loadForm('raboti');

        
    }



    /**
     * @event construct 
     */
    function doConstruct(UXEvent $e = null)
    {    
        $this->moneybalance->text = Score::get('money');
    }






    /**
     * @event button4.action 
     */
    function doButton4Action(UXEvent $e = null)
    {
$e = $event ?: $e; // legacy code from 16 rc-2

		$this->loadForm('texpoderjka');

        
    }



    /**
     * @event image.click 
     */
    function doImageClick(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		app()->showFormAndWait('vkusnoitochka');

        
    }

    /**
     * @event imageAlt.click 
     */
    function doImageAltClick(UXMouseEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		app()->showForm('tsum');

        
    }

    /**
     * @event buttonAlt.action 
     */
    function doButtonAltAction(UXEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		app()->showForm('scores');

        
    }

    /**
     * @event button3.action 
     */
    function doButton3Action(UXEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		app()->showForm('hrenphone');

        
    }

    /**
     * @event button5.action 
     */
    function doButton5Action(UXEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		$this->loadForm('osntotsum');

        
    }






}
