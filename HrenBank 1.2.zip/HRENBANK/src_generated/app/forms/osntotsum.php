<?php
namespace app\forms;

use std, gui, framework, app;
use action\Score;

class osntotsum extends AbstractForm
{

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		$this->loadForm('raboti');

        $text = $this->balanceTotsum->text;
        if ($text > Score::get('score')){
            UXDialog::showAndWait('У вас нет столько денег!');
            $this->loadForm('MainForm');
        }
        elseif ($text < 0){
            UXDialog::showAndWait('Вы не можете перевести отрицательное количество!');
            $this->loadForm('MainForm');
        }
        else{
            UXDialog::showAndWait('Вы успешно перевели деньги с основного баланса на баланс ЦУМа');
            Score::inc('tsumbalance', $text);
            Score::inc('score', -$text);
            $this->loadForm('MainForm');
            $this->remove(form('raboti'));
        }
    }

}
