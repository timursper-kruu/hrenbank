<?php
namespace app\modules;

use std, gui, framework, app;
use action\Score;
use action\Element; 

class AppModule extends AbstractModule
{

    /**
     * @event promo.action 
     */
    function doPromoAction(ScriptEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		app()->showFormAndWait('promo');

        
    }

    /**
     * @event reset.action 
     */
    function doResetAction(ScriptEvent $e = null)
    {    
        Score::set('score', 0);
        UXDialog::showAndWait('Ваш баланс теперь 0! Обновите баланс');
    }

    /**
     * @event mm.action 
     */
    function doMmAction(ScriptEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		$this->loadForm('MainForm');

        
    }

    /**
     * @event balanceupd.action 
     */
    function doBalanceupdAction(ScriptEvent $e = null)
    {    
$e = $event ?: $e; // legacy code from 16 rc-2

		Element::setText($this->form('MainForm')->moneybalance, \action\Score::get('score'));
		Element::setText($this->form('scores')->labelAlt, \action\Score::get('score'));
		Element::setText($this->form('tsum')->label3, \action\Score::get('tsumbalance'));
		Element::setText($this->form('scores')->label4, \action\Score::get('tsumbalance'));

        
    }




}
