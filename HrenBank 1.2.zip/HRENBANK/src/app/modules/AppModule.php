<?php
namespace app\modules;

use std, gui, framework, app;
use action\Score;

class AppModule extends AbstractModule
{

    /**
     * @event promo.action 
     */
    function doPromoAction(ScriptEvent $e = null)
    {    
        
    }

    /**
     * @event reset.action 
     */
    function doResetAction(ScriptEvent $e = null)
    {    
        Score::set('score', 0);
        UXDialog::showAndWait('Ваш баланс теперь 0! Обновите баланс');
    }

    /**
     * @event mm.action 
     */
    function doMmAction(ScriptEvent $e = null)
    {    
        
    }

    /**
     * @event balanceupd.action 
     */
    function doBalanceupdAction(ScriptEvent $e = null)
    {    
        
    }




}
