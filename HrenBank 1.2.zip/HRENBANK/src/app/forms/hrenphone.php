<?php
namespace app\forms;

use std, gui, framework, app;


class hrenphone extends AbstractForm
{

    /**
     * @event image.click 
     */
    function doImageClick(UXMouseEvent $e = null)
    {    
        
    }

}
