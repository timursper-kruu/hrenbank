<?php
namespace app\forms;

use std, gui, framework, app;


class tsum extends AbstractForm
{

    /**
     * @event buttonAlt.action 
     */
    function doButtonAltAction(UXEvent $e = null)
    {
        $money = Score::get('tsumbalance');
        if ($money < 74300){
            UXDialog::showAndWait('У вас нету 74,300 рублей!');
        }
        else{
            Score::inc('score', -74300);
            UXDialog::showAndWait('Вы успешно стали дебиком купив эту рубаху!');
        }
    }

    /**
     * @event label3.construct 
     */
    function doLabel3Construct(UXEvent $e = null)
    {    
        
    }

}
