<?php
namespace app\forms;

use std, gui, framework, app;


class scores extends AbstractForm
{

    /**
     * @event labelAlt.construct 
     */
    function doLabelAltConstruct(UXEvent $e = null)
    {    
        
    }

    /**
     * @event label4.construct 
     */
    function doLabel4Construct(UXEvent $e = null)
    {    
        
    }

}
