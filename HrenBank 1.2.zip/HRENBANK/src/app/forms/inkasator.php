<?php
namespace app\forms;

use std, gui, framework, app;
use action\Score;

class inkasator extends AbstractForm
{

    /**
     * @event image.click 
     */
    function doImageClick(UXMouseEvent $e = null)
    {    
        Score::inc('score', 500);
        $this->loadForm('MainForm');
    }

}
