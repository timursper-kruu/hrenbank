<?php
namespace app\forms;

use std, gui, framework, app;


class MainForm extends AbstractForm
{

    $money = 0;

    /**
     * @event moneybalance.construct 
     */
    function doMoneybalanceConstruct(UXEvent $e = null)
    {    
        
    }



    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {    
        
    }



    /**
     * @event construct 
     */
    function doConstruct(UXEvent $e = null)
    {    
        $this->moneybalance->text = Score::get('money');
    }






    /**
     * @event button4.action 
     */
    function doButton4Action(UXEvent $e = null)
    {
        
    }



    /**
     * @event image.click 
     */
    function doImageClick(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event imageAlt.click 
     */
    function doImageAltClick(UXMouseEvent $e = null)
    {    
        
    }

    /**
     * @event buttonAlt.action 
     */
    function doButtonAltAction(UXEvent $e = null)
    {    
        
    }

    /**
     * @event button3.action 
     */
    function doButton3Action(UXEvent $e = null)
    {    
        
    }








}
