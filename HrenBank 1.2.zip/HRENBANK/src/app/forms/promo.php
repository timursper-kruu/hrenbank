<?php
namespace app\forms;

use std, gui, framework, app;
use php\gui\UXTextField;
use action\Score;

class promo extends AbstractForm
{

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {    
        $text = $this->promo->text;
        if ($text == "itb"){
            Score::inc('score', 1000);
            UXDialog::showAndWait('Вам выдано 1000 рублей! Не забудьте обновить баланс');
        }
        elseif ($text == "123465789"){
            Score::inc('score', 2500);
            UXDialog::showAndWait('Вам выдано 2500 рублей! Не забудьте обновить баланс');
        }
        elseif ($text == "324567"){
            Score::inc('score', 320);
            UXDialog::showAndWait('Вам выдано 320 рублей! Не забудьте обновить баланс');
        }
        elseif ($text == "tsum"){
            Score::inc('tsumbalance', 100000);
            UXDialog::showAndWait('Вам выдано 100к рублей на баланс ЦУМ! Не забудьте обновить баланс');
        }
        else{
            UXDialog::showAndWait('Промокод неверный!');
        }
    }


}
