<?php
namespace app\forms;

use std, gui, framework, app;


class texpoderjka2 extends AbstractForm
{

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {    
        
    }

}
